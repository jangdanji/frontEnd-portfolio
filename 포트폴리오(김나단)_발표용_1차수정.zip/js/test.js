// let num = 0

// setInterval(() => {
    
//     num = (num + 1) % 3
//     console.log(num)

// }, 2000);

